/*
 * http://github.com/dusty-nv/jetson-reinforcement
 */

#include "aiAgent.h"


// constructor
aiAgent::aiAgent()
{

}


// destructor
aiAgent::~aiAgent()
{

}

